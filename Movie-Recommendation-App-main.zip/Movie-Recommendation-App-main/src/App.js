import React from 'react';
import MovieApp from './components/MovieApp';

const App = () => {
  return (
   
      <div className="App">
            <MovieApp />
      </div>
    
  );
};

export default App;

